import { Web3Provider } from '@ethersproject/providers';
import * as OnchainID from '@onchain-id/solidity';

import { IdentitySDK } from '../../../dist';
import { getTestProvider } from '../helpers/ganache.helper';
import { Contract, ContractFactory, Signer } from 'ethers';
import { KeyPurpose, KeyType } from '../../../dist/identity/Key.interface';

describe('Test key management on Identity', () => {
  let provider: Web3Provider;
  let signer: Signer;
  let implementation: Contract;
  let implementationAuthority: Contract;

  beforeEach(async () => {
    provider = await getTestProvider();
    signer = provider.getSigner(0);

    implementation = await new ContractFactory(OnchainID.contracts.Identity.abi, OnchainID.contracts.Identity.bytecode, provider.getSigner(6))
      .deploy(
        await provider.getSigner(6).getAddress(),
        true,
      );
    await implementation.deployed();

    implementationAuthority = await new ContractFactory(OnchainID.contracts.ImplementationAuthority.abi, OnchainID.contracts.ImplementationAuthority.bytecode, provider.getSigner(6))
      .deploy(implementation.address);
    await implementationAuthority.deployed();
  });

  async function deployIdentity(managementKey: string): Promise<IdentitySDK.Identity> {
    const identity = await IdentitySDK.Identity.deployNew({
      managementKey,
      implementationAuthority: implementationAuthority.address,
    }, { signer });
    await identity.deployed();

    return identity;
  }

  describe('.addKey', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when key is not valid', () => {
      it('throws a InvalidKeyError', async () => {
        await expect(identity.addKey('adadzad', KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer })).rejects.toThrow('Definition of the Key is not valid.');
      });
    });

    describe('when key already has the purpose', () => {
      let key: string;
      beforeEach(async () => {
        key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer });
      });

      it('throws a KeyPurposeAlreadyRegisteredError', async () => {
        await expect(identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer })).rejects.toThrow('Key already has purpose on identity contract.');
      });
    });

    describe('when key does not have the purpose', () => {
      describe('when signer is missing a MANAGEMENT key', () => {
        it('throw a OperationForbiddenError', async () => {
          const key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
          await expect(identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer: provider.getSigner(1) })).rejects.toThrow('MANAGEMENT key required on the identity to add a key.');
        });
      });

      describe('when signer is authorized to update keys', () => {
        it('adds the purpose to the key', async () => {
          const key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
          await identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer });
        });
      });
    });
  });

  describe('.removeKey', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when key is not valid', () => {
      it('throws a InvalidKeyError', async () => {
        await expect(identity.removeKey('adadzad', KeyPurpose.MANAGEMENT, { signer })).rejects.toThrow('Definition of the Key is not valid.');
      });
    });

    describe('when key has the purpose', () => {
      let key: string;
      beforeEach(async () => {
        key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer });
      });

      describe('when signer is missing a MANAGEMENT key', () => {
        it('throw a OperationForbiddenError', async () => {
          const key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
          await expect(identity.removeKey(key, KeyPurpose.MANAGEMENT, { signer: provider.getSigner(1) })).rejects.toThrow('MANAGEMENT key required on the identity to remove a key.');
        });
      });

      describe('when signer is authorized to update keys', () => {
        it('removes the key', async () => {
          await identity.removeKey(key, KeyPurpose.MANAGEMENT, { signer });
        });
      });
    });

    describe('when key does not have the purpose', () => {
      it('throws a KeyPurposeAlreadyRegisteredError', async () => {
        const key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await expect(identity.removeKey(key, KeyPurpose.MANAGEMENT, { signer })).rejects.toThrow('Key does not have the purpose on identity contract.');
      });
    });
  });

  describe('.getKey', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when key does not exist on the identity contract', () => {
      it('should return null', async () => {
        const key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await expect(identity.getKey(key)).resolves.toBeNull;
      });
    });

    describe('when key is on identity contract', () => {
      let key: string;
      beforeEach(async () => {
        key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer });
      });

      it('should return the key and its purposes', async () => {
        await expect(identity.getKey(key)).resolves.toMatchObject({
          key,
          purposes: [KeyPurpose.MANAGEMENT],
          type: KeyType.ECDSA,
        });
      });
    });
  });

  describe('.getKeyPurposes', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when key does not exist on the identity contract', () => {
      it('should return an empty array', async () => {
        const key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await expect(identity.getKeyPurposes(key)).resolves.toHaveLength(0);
      });
    });

    describe('when key is on identity contract', () => {
      let key: string;
      beforeEach(async () => {
        key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer });
      });

      it('should return the key and its purposes', async () => {
        await expect(identity.getKeyPurposes(key)).resolves.toStrictEqual([KeyPurpose.MANAGEMENT]);
      });
    });
  });

  describe('.keyHasPurpose', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when key does not exist on the identity contract', () => {
      it('should return false', async () => {
        const key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await expect(identity.keyHasPurpose(key, KeyPurpose.MANAGEMENT)).resolves.toBeFalsy;
      });
    });

    describe('when key is on identity contract without the purpose', () => {
      let key: string;
      beforeEach(async () => {
        key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await identity.addKey(key, KeyPurpose.CLAIM, KeyType.ECDSA, { signer });
      });

      it('should return false', async () => {
        await expect(identity.keyHasPurpose(key, KeyPurpose.MANAGEMENT)).resolves.toBeFalsy;
      });
    });

    describe('when key is on identity contract with the purpose', () => {
      let key: string;
      beforeEach(async () => {
        key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
        await identity.addKey(key, KeyPurpose.CLAIM, KeyType.ECDSA, { signer });
      });

      it('should return false', async () => {
        await expect(identity.keyHasPurpose(key, KeyPurpose.CLAIM)).resolves.toBeTruthy;
      });
    });
  });

  describe('.getKeysByPurpose', () => {
    let identity: IdentitySDK.Identity;
    let key: string;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())

      key = IdentitySDK.utils.encodeAndHash(['address'], ['0xAd5c0B641376DefC74158e1a6AE447705d08E988']);
      await identity.addKey(key, KeyPurpose.MANAGEMENT, KeyType.ECDSA, { signer });
    });

    it('should return the two keys', async () => {
      const keys = await identity.getKeysByPurpose(KeyPurpose.MANAGEMENT);
      expect(keys).toHaveLength(2);
    });
  });
});
