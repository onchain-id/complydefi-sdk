import { Web3Provider } from '@ethersproject/providers';
import OnchainId from '@onchain-id/solidity';

import { IdentitySDK } from "../../../dist";
import { getTestProvider } from '../helpers/ganache.helper';
import { Contract, ContractFactory } from 'ethers';

describe('Test deployment of Identity', () => {
  let provider: Web3Provider;
  let implementation: Contract;
  let implementationAuthority: Contract;
  beforeEach(async () => {
    provider = await getTestProvider();
    implementation = await new ContractFactory(OnchainId.contracts.Identity.abi, OnchainId.contracts.Identity.bytecode, provider.getSigner(6))
      .deploy(
        await provider.getSigner(6).getAddress(),
        true,
      );
    await implementation.deployed();
    implementationAuthority = await new ContractFactory(OnchainId.contracts.ImplementationAuthority.abi, OnchainId.contracts.ImplementationAuthority.bytecode, provider.getSigner(6))
      .deploy(implementation.address);
    await implementationAuthority.deployed();
  });

  it('should deploy a new Identity and wait for it to be deployed', async () => {
    const identity = await IdentitySDK.Identity.deployNew({
      implementationAuthority: implementationAuthority.address,
      managementKey: await provider.getSigner(0).getAddress(),
    }, { signer: provider.getSigner(0) });

    expect(identity).toBeInstanceOf(IdentitySDK.Identity);
    expect(identity).toHaveProperty('address');

    await identity.deployed();
  });
});
