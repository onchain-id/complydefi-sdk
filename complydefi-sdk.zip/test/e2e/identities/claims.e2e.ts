import { Web3Provider } from '@ethersproject/providers';
import * as OnchainID from '@onchain-id/solidity';

import { getTestProvider } from '../helpers/ganache.helper';
import { Contract, ContractFactory, Signer } from 'ethers';
import { KeyType, KeyPurpose} from "../../../dist/identity/Key.interface";
import { IdentitySDK } from '../../../src';

describe('Test claim management on Identity', () => {
  let provider: Web3Provider;
  let signer: Signer;
  let implementation: Contract;
  let implementationAuthority: Contract;

  beforeEach(async () => {
    provider = await getTestProvider();
    signer = provider.getSigner(0);

    implementation = await new ContractFactory(OnchainID.contracts.Identity.abi, OnchainID.contracts.Identity.bytecode, provider.getSigner(6))
      .deploy(
        await provider.getSigner(6).getAddress(),
        true,
      );
    await implementation.deployed();

    implementationAuthority = await new ContractFactory(OnchainID.contracts.ImplementationAuthority.abi, OnchainID.contracts.ImplementationAuthority.bytecode, provider.getSigner(6))
      .deploy(implementation.address);
    await implementationAuthority.deployed();
  });

  async function deployIdentity(managementKey: string): Promise<IdentitySDK.Identity> {
    const identity = await IdentitySDK.Identity.deployNew({
      managementKey,
      implementationAuthority: implementationAuthority.address,
    }, { signer });
    await identity.deployed();

    return identity;
  }

  describe('.addClaim', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when signer is missing CLAIM key on the identity', () => {
      it('should throw an OperationForbiddenError', async () => {
        await expect(identity.addClaim(1, 1, '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', '0xaa', '0x', '', { signer: provider.getSigner(1) })).rejects.toThrow('CLAIM key required on the identity to add a claim.');
      });
    });

    describe('when signer is authorized to update claims', () => {
      beforeEach(async () => {
        const key = IdentitySDK.utils.encodeAndHash(['address'], [await provider.getSigner(1).getAddress()]);
        await identity.addKey(key, KeyPurpose.CLAIM, KeyType.ECDSA, { signer: provider.getSigner(0) });
      });

      it('should add the claim to the identity', async () => {
        await identity.addClaim(1, 1, '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', '0xaa', '0x', '', { signer: provider.getSigner(1) })
        await expect(identity.getClaimIdsByTopic(1)).resolves.toHaveLength(1);
      });
    });
  });

  describe('.removeClaim', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when signer is missing CLAIM key on the identity', () => {
      it('should throw an OperationForbiddenError', async () => {
        await expect(identity.removeClaim('0x12', { signer: provider.getSigner(1) })).rejects.toThrow('CLAIM key required on the identity to remove a claim.');
      });
    });

    describe('when signer is authorized to update claims', () => {
      beforeEach(async () => {
        const key = IdentitySDK.utils.encodeAndHash(['address'], [await provider.getSigner(1).getAddress()]);
        await identity.addKey(key, KeyPurpose.CLAIM, KeyType.ECDSA, { signer: provider.getSigner(0) });
      });

      describe('when claim does not exist on the identity', () => {
        it('should throw a NonExistingClaimError', async () => {
          await expect(identity.removeClaim(IdentitySDK.Claim.generateClaimID('0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', 1), { signer: provider.getSigner(1) })).rejects.toThrow('The specified claim ID was not found on the Identity.');
        });
      });

      describe('when claim does exist on the identity', () => {
        beforeEach(async () => {
          await identity.addClaim(1, 1, '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', '0xaa', '0x', '', { signer: provider.getSigner(1) });
        });

        it('should remove the claim from the identity', async () => {
          await expect(identity.getClaimIdsByTopic(1)).resolves.toHaveLength(1);
          await identity.removeClaim(IdentitySDK.Claim.generateClaimID('0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', 1), { signer: provider.getSigner(1) });
          await expect(identity.getClaimIdsByTopic(1)).resolves.toHaveLength(0);
        });
      });
    });
  });

  describe('.getClaim', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())
    });

    describe('when claim does not exist on identity', () => {
      it('should return null', async () => {
        await expect(identity.getClaim(IdentitySDK.Claim.generateClaimID('0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', 1))).resolves.toBeNull;
      });
    });

    describe('when claim exists on identity', () => {
      beforeEach(async () => {
        await identity.addClaim(1, 1, '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', '0xaa', '0x', '', { signer: provider.getSigner(0) });
      });

      it('should return the claim', async () => {
        const claim = await identity.getClaim(IdentitySDK.Claim.generateClaimID('0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', 1));
        expect(claim).toHaveProperty('issuer', '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC');
      });
    });
  });

  describe('.getClaimsByTopic', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())

      await identity.addClaim(1, 1, '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', '0xaa', '0x', '', { signer: provider.getSigner(0) });
      await identity.addClaim(1, 1, '0x61B87D9344b3597c2bDF5770A08d856B5C34e43c', '0xaa', '0x', '', { signer: provider.getSigner(0) });
    });

    it('returns the claims for the topic', async () => {
      const claims = await identity.getClaimsByTopic(1);
      expect(claims).toHaveLength(2);
      expect(claims[0]).toHaveProperty('issuer', '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC');
      expect(claims[1]).toHaveProperty('issuer', '0x61B87D9344b3597c2bDF5770A08d856B5C34e43c');
    });
  });

  describe('.getClaimIdsByTopic', () => {
    let identity: IdentitySDK.Identity;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())

      await identity.addClaim(1, 1, '0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', '0xaa', '0x', '', { signer: provider.getSigner(0) });
      await identity.addClaim(1, 1, '0x61B87D9344b3597c2bDF5770A08d856B5C34e43c', '0xaa', '0x', '', { signer: provider.getSigner(0) });
    });

    it('returns the claims for the topic', async () => {
      const claims = await identity.getClaimIdsByTopic(1);
      expect(claims).toHaveLength(2);
      expect(claims[0]).toEqual(IdentitySDK.Claim.generateClaimID('0x13A4CC8Dc7a98A1c6A064E83504C6Bbc45a299aC', 1))
      expect(claims[1]).toEqual(IdentitySDK.Claim.generateClaimID('0x61B87D9344b3597c2bDF5770A08d856B5C34e43c', 1))
    });
  });

  describe('.verifyClaim', () => {
    let identity: IdentitySDK.Identity;
    let claimIssuer: Contract;
    beforeEach(async () => {
      identity = await deployIdentity(await provider.getSigner(0).getAddress())

      const claimIssuerFactory = new ContractFactory(OnchainID.contracts.ClaimIssuer.abi, OnchainID.contracts.ClaimIssuer.bytecode, provider.getSigner(1));
      claimIssuer = await claimIssuerFactory.deploy(await provider.getSigner(1).getAddress()).then(c => c.deployed());
      const claimIssuerIdentity = await IdentitySDK.Identity.at(claimIssuer.address, { signer: provider.getSigner(1) });
      await claimIssuerIdentity.addKey(
        IdentitySDK.utils.encodeAndHash(['address'], [await provider.getSigner(2).getAddress()]),
        KeyPurpose.CLAIM,
        KeyType.ECDSA,
        { signer: provider.getSigner(1) },
      ).then((tx: any) => tx.wait());
    });

    describe('when claim is not on identity', () => {
      it('should return false', async () => {
        await expect(identity.verifyClaim(IdentitySDK.Claim.generateClaimID('0x61B87D9344b3597c2bDF5770A08d856B5C34e43c', 1), { provider })).rejects.toThrow('Claim is not complete and thus cannot be verified.');
      });
    });

    describe('when claim is valid', () => {
      let claim: IdentitySDK.Claim;
      beforeEach(async () => {
        claim = new IdentitySDK.Claim({
          address: identity.address,
          issuer: claimIssuer.address,
          data: '0x12',
          topic: 1,
          scheme: 1,
          uri: '',
        });
        await claim.sign(new IdentitySDK.SignerModule(provider.getSigner(2)));

        await identity.addClaim(
          claim.topic!,
          claim.scheme!,
          claim.issuer!,
          claim.signature!,
          claim.data!,
          claim.uri!,
          { signer: provider.getSigner(0) },
        ).then(tx => tx.wait());
      });

      it('should return true', async () => {
        await expect(identity.verifyClaim(claim, { provider })).resolves.toBeTruthy;
      });
    });

    describe('when claim is not valid', () => {
      let claim: IdentitySDK.Claim;
      beforeEach(async () => {
        claim = new IdentitySDK.Claim({
          address: identity.address,
          issuer: claimIssuer.address,
          data: '0x12',
          topic: 1,
          scheme: 1,
          uri: '',
        });
        await claim.sign(new IdentitySDK.SignerModule(provider.getSigner(3)));

        await identity.addClaim(
          claim.topic!,
          claim.scheme!,
          claim.issuer!,
          claim.signature!,
          claim.data!,
          claim.uri!,
          { signer: provider.getSigner(0) },
        ).then(tx => tx.wait());
      });

      it('should return false', async () => {
        await expect(identity.verifyClaim(claim, { provider })).resolves.toBeFalsy;
      });
    });
  });
});
