import { getDefaultProvider, Wallet } from 'ethers';
import { Identity } from '../../../dist';
import { InvalidAddressError } from '../../../src/core/utils/ENS';
import { Provider } from '@ethersproject/providers';
import { InvalidProviderError } from '../../../src/core/errors/Errors';

describe('Identity ❖ Initializer and Resolver', function() {
  let provider: Provider;
  beforeAll(() => {
    provider = getDefaultProvider('homestead');
  });

  describe('new - Identity Constructor', function() {
    describe('when string is a valid ETH address', function() {
      it('should instantiate a new Identity object', async function() {
        const identity = new Identity('0x1fA0037fF481A7fDE656B8cE9dA1cCa5D09630f7', provider);

        expect(identity).toHaveProperty('address', '0x1fA0037fF481A7fDE656B8cE9dA1cCa5D09630f7');
      });
    });

    describe('when string is not a valid ETH address', function() {
      it('should throw an InvalidAddressError', async function() {
        expect(() => new Identity('adazd.eth', provider)).toThrow(new InvalidAddressError());
      });
    });
  });

  describe('at() - Identity from address or ENS', function() {
    describe('when string is a valid ETH address', function() {
      describe('when using a provider', function() {
        it('should instantiate a new Identity object', async function() {
          const identity = await Identity.at('0x1fA0037fF481A7fDE656B8cE9dA1cCa5D09630f7', { provider: provider });

          expect(identity).toHaveProperty('address', '0x1fA0037fF481A7fDE656B8cE9dA1cCa5D09630f7');
        });
      });
    });

    describe('when string is not a valid ETH address', function() {
      describe('when ENS does not resolve', function() {
        it('should throw an error', async function() {
          await expect(Identity.at('naa.eth', { provider: provider })).rejects.toThrow(new InvalidAddressError({ message: 'Could not resolve the ENS to an ethereum address.' }));
        });
      });

      describe('when ENS does resolve', function() {
        describe('when using a signer with a provider',  function() {
          it('should instantiate a new Identity object to the resolved address', async function() {
            const signer = new Wallet('0x7636C9F40D8DE5C022AF21ABB368923992A26E2C55EB5ABE597626906A018BAF', provider);
            const identity = await Identity.at('nakasar.eth', { signer });

            expect(identity).toHaveProperty('address', '0x1fA0037fF481A7fDE656B8cE9dA1cCa5D09630f7');
          });
        });

        describe('when using a signer without a provider',  function() {
          it('should instantiate a new Identity object', async function() {
            const signer = new Wallet('0x7636C9F40D8DE5C022AF21ABB368923992A26E2C55EB5ABE597626906A018BAF');

            await expect(Identity.at('nakasar.eth', { signer })).rejects.toThrow(new InvalidProviderError('Resolving ENS requires a Provider.'));
          });
        });

        describe('when using a provider',  function() {
          it('should instantiate a new Identity object to the resolved address', async function() {
            const identity = await Identity.at('nakasar.eth', { provider: provider });

            expect(identity).toHaveProperty('address', '0x1fA0037fF481A7fDE656B8cE9dA1cCa5D09630f7');
          });
        });
      });
    });
  });
});
