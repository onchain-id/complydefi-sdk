import { IdentitySDK } from '../../../dist';
import { Wallet } from 'ethers';

describe('Test claim signature', () => {
  describe('.generateHash', () => {
    it('should generate the proper hash', () => {
      expect(IdentitySDK.Claim.generateHash(
        12313444256,
        new Date('2020-05-26T14:20:19.498Z'),
        {},
        {}
      )).toEqual('0x4d7f9ff1fa41ad8e60be1ed676170f390f996a97686b4fc11d3c26a0cbef5bf2');
    })
  });

  describe('.generateBlockchainHash', () => {
    it('Should generate the correct blockchain hash', () => {
      expect(IdentitySDK.Claim.generateBlockchainHash(
        '0xbEA1e86d493116615eef93559B1c2e6E02620601',
        11314514,
        '0x12554deafa'
      )).toEqual('0x9b287b568ed571e0d9e104bafef0f85c05b0f855443a4c621c12c32c8c485ed8');
    });
  });

  describe('.generateClaimID', () => {
    it('Should generate the correct claim ID', () => {
      expect(IdentitySDK.Claim.generateClaimID(
        '0xbEA1e86d493116615eef93559B1c2e6E02620601',
        11297384235,
      )).toEqual('0xa6326b9cd508e5448dd23119237d239670bd2e24d9d038b270bb5ccc6ccda313');
    });
  });

  describe('.sign',  () => {
    it('Should generate the correct signature', async () => {
      await expect(IdentitySDK.Claim.sign(
        129912974,
        '0xbEA1e86d493116615eef93559B1c2e6E02620601',
        '0x123247adef',
        new IdentitySDK.SignerModule(new Wallet('0xE188AFA1480EB0A7BB8E7A86D8B0EC5FB0B93915F67B403F9F112D75B805F24B')),
      )).resolves.toEqual('0xe81536fcaaf08cfc9f9cb4667d628bd1f57753c115a25c40ff274bd5ebff210f1b1f9e0a573d458f2e3d25dff2d145fa983fc21ca55990016478dac369174d8c1c');
    });
  });
});
