import { IdentitySDK } from "../../dist";

describe('Test exported module', () => {
  it('should export a module IdentitySDK with Claim, Identity and utils', () => {
    expect(IdentitySDK).toHaveProperty('Claim');
    expect(IdentitySDK).toHaveProperty('Identity');
    expect(IdentitySDK).toHaveProperty('utils');
  });
});
