 # Implementing a Claim Issuer for Blockchain Identities
 
We are going to bootstrap a new service that allow users to obtain a fingerprinted proof of their information.
In this tutorial, our service will ask for the email of the user and send a verification link in the mailbox.
Once the user click the link, the email will be marked as verified and an email claim will be issued.
Let's call this project the Email Verification Service.

Our service will follow the [OnchainID](https://onchainid.com) standard for Blockchain Identities.
Reach for the official website and documentation to learn more about the OnchainID standard.

## Bootstrapping an API

For the sake of this tutorial, we will use a very simple `express` server.

First and foremost, create a new folder for your `./email-verification-service`.

Init your npm package `npm init`. You may leave the fields as default.

Install the dependencies required for this tutorial. We will use `express` to run the API server `npm install express`.

Some dev-dependencies will also be useful. `nodemon` watch our files and restart after each code change: `npm install --save-dev nodemon`.

Let's create our first file that define our API:

```javascript
// ./app.js
const express = require('express');
const app = express();

app.use(express.json());

app.listen(8080, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  
  console.info('Email Verification Service up an running 🎉');
});
```

We won't use any database here and store everything in memory,
but of course, you would connect to a persistence storage.

Let's update our `package.json` with an appropriate dev start script that automatically reloads on each code change:

```json
{
  "scripts": {
      "start": "node app.js",
      "start:dev": "nodemon app.js"
  }
}
```

## Authenticate Identities

In order to obtain a claim, a user must have a blockchain Identity that follows the ERC734 and ERC735 Ethereum standards.
The Blockchain Identity is also used has an authentication method.
Our first step is naturally to sign in users using their identities.

The SignIn with Identity is a challenge-based authentication.
The service generates a unique access challenge that the owner of the Identity signs with a key that is attached to the Identity.
The service then checks if the key used to sign the challenge is attached on the Identity in the blockchain Identity contract.
If it is still valid, then the user authentication is valid, and the service generates an access token.  

```mermaid
sequenceDiagram
  participant U as User
  participant S as Service
  participant B as Blockchain

  U ->> S: auth challenge request
  activate S
  S ->> S: Generate and store challenge
  S ->> U: auth challenge
  deactivate S
  activate U
  U ->> U: Sign challenge with wallet
  U ->> S: signed challenge
  deactivate U
  activate S
  S ->> S: Compute signature key
  S ->> B: Check key validity for identity
  deactivate S
  activate B
  B ->> S: Identity has key
  deactivate B
  activate S
  S ->> U: access token
  deactivate S
```

Let's create a route on which users can request an auth challenge.
The user only sends the address of the Identity he wants to sign in with.

We will use random `uuid/v4` to generate unique identifiers for the challenge, install with `npm i uuid`.

To interact with Identities, we will use the Identity SDK: `npm i @onchain-id/identity-sdk`.

```javascript
// ./routes/auth.routes.js
const express = require('express');
const IdentitySDK = require('@onchain-id/identity-sdk');
const uuidv4 = require('uuid/v4');

const router = express.Router();

const authChallenges = [];

router.post('/auth-challenges', async (req, res, next) => {
  try {
    const { identityAddress } = req.body;
    
    let identity;
    try {
      identity = await IdentitySDK.Identity.at(identityAddress);
    } catch (err) {
      res.status(400);
      return res.json({ error: true, status: 400, message: 'The provided identityAddress is not a valid Ethereum address or the ENS could not be resolved.', name: 'INVALID_IDENTITY_ADDRESS' });
    }
    
    const authChallenge = {
      id: uuidv4(),
      identityAddress: identity.address,
      status: 'PENDING',
      challenge: '',
    };
    
    authChallenge.challenge = `By signing this message, you will authenticate with the Email Verification Service\n\nChallengeID:${authChallenge.id};`;
    
    authChallenges.push(authChallenge);
    
    res.status(201);
    return res.json({
      ...authChallenge,
      _links: {
        _self: `/auth/auth-challenges/${authChallenge.id}`,
        validations: `/auth/auth-challenges/${authChallenge.id}/validations`,
      },
    });
  } catch (err) {
    console.error(err);
    
    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
});

module.exports = router;
```

Update the `app.js` file to include the new router. Also configure the default blockchain provider for the Identity SDK:

```javascript
// ./app.js
const express = require('express');
const IdentitySDK = require('@onchain-id/identity-sdk');

const AuthRoutes = require('./routes/auth.routes');

IdentitySDK.Config.setProvider('homestead');

const app = express();

app.use(express.json());

app.use('/auth', AuthRoutes);

app.listen(8080, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  
  console.info('Email Verification Service up an running 🎉');
});
```

Now, let's create a route to validate the signed challenges and generate a json web token.

We will use `jsonwebtoken` to generate and validate access tokens: `npm i jsonwebtoken`. 

Add a new route in `./routes/auth.routes.js`:

```javascript
const IdentitySDK = require('@onchain-id/identity-sdk');
const jwt = require('jsonwebtoken');

// ./routes/auth.routes.js
const authChallenges = [];

router.post('/auth-challenges/:authChallengeID/validations', async (req, res, next) => {
  try {
    const { authChallengeID } = req.params;
    const { signature } = req.body;
    
    const authChallenge = authChallenges.find(authChallenge => authChallenge.id === authChallengeID);
    
    if (!authChallenge) {
      res.status(400);
      return res.json({ error: true, status: 404, message: 'There is no auth challenge with this id to validate.', name: 'AUTH_CHALLENGE_NOT_FOUND' });
    }
    
    let isValid = false;
    try {
      let identity;
      try {
        identity = await IdentitySDK.Identity.at(authChallenge.identityAddress);
      } catch (err) {
        res.status(400);
        return res.json({ error: true, status: 400, message: 'The provided identityAddress is not a valid Ethereum address or the ENS could not be resolved.', name: 'INVALID_IDENTITY_ADDRESS' });
      }
      
      isValid = await identity.validateSignature(authChallenge.challenge, signature);      
    } catch (err) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'The provided signature is invalid, or an error occurred while attempting to validate the signature key.', name: 'INVALID_AUTH_CHALLENGE_SIGNATURE' });
    }
   
    if (!isValid) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'The provided signature is invalid, or the key is not associated to the Identity', name: 'INVALID_AUTH_CHALLENGE_SIGNATURE' });
    }
    
    authChallenge.status = 'COMPLETE';
    
    const accessToken = jwt.sign({ sub: authChallenge.identityAddress }, 'my_secret');
    
    res.status(201);
    return res.json({ accessToken });
  } catch (err) {
    console.error(err);
    
    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
});
```

Finally, let's create a middleware that checks for the presence of the access token in the Authorization header:

```javascript
// ./middlewares/auth.middleware.js

const jwt = require('jsonwebtoken');

/**
 * Parse authentication data if they are given and populate req.locals.authentication.
 * req.locals.authenticate will be null if no authentication is found. Otherwise { isValid: true|false, data: Object }.
 * isValid is true when authentication is a success, false if validation failed.
 *
 * @param {object} req - Express request object
 * @param {object} res - Express response object
 * @param {function} next - Callback function
 */
async function authenticateIdentity(req, res, next) {
  try {
    const { authorization } = req.headers;
    const { identityAddress } = req.params;
    
    if (!authorization) {
      res.status(401);
      return res.json({ error: true, status: 401, message: 'Missing a Bearer token in Authorization header.', name: 'UNAUTHORIZED' });
    }
    
    const token = authorization.split('Bearer ')[1];
    if (!token) {
      res.status(401);
      return res.json({ error: true, status: 401, message: 'Missing a Bearer token in Authorization header.', name: 'UNAUTHORIZED' });
    }
    
    let payload;
    try {
      payload = await jwt.verify(token, 'my_secret');
    } catch (err) {
      res.status(401);
      return res.json({ error: true, status: 401, message: 'The token is not valid.', name: 'UNAUTHORIZED' });
    }
    
    if (payload.identityAddress !== identityAddress) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'The token does not grand access to this Identity.', name: 'FORBIDDEN' });
    }
    
    return next();
  } catch (err) {
    console.error(err);
            
    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
}

module.exports = { authenticateIdentity };
```

## Collecting and verifying emails

Now that we have a way to authenticate users, we need to collect their email. Once again, we will store everything in memory.

We will create a new route to allow users to link an email to an Identity and trigger the verification, and another one to complete the verification (the link sent in the email).

```javascript
// ./routes/emails.routes.js
const express = require('express');
const uuidv4 = require('uuid/v4');

const { authenticateIdentity } = require('../middlewares/auth.middleware');

const router = express.Router();

const emails = [];

router.post('/identities/:identityAddress/email', authenticateIdentity, async (req, res, next) => {
  try {
    const { identityAddress } = req.params;
    const { body } = req;
    
    let email = emails.find(email => email.identityAddress === identityAddress || email.email === body.email);
    
    if (email) {
      if (email.status === 'VERIFIED') {
        res.status(409);
        return res.json({ error: true, status: 409, message: 'The identity already has a verified email or this email is already linked to an Identity.', name: 'EMAIL_ALREADY_VERIFIED' });
      }
      
      if (email.identityAddress !== identityAddress) {
        email = {};
        
        emails.push(email);
      }
    } else {
      email = {};
      
      emails.push(email);
    }
    
    email.email = body.email;
    email.identityAddress = identityAddress;
    email.status = 'AWAITING_CONFIRMATION';
    email.code = uuidv4();
    
    // Here you should send an email with the code, but but testing purpose, let's just print the code in console.
    console.log(email.code);
    
    res.status(201);
    return res.json({
      identityAddress: email.identityAddress,
      status: email.status,
      email: email.email,
      _links: {
        _self: `/identities/${identityAddress}/email`,
        validations: `/identities/${identityAddress}/email/validations`,
      },
    });
  } catch (err) {
    console.error(err);
        
    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
});

router.post('/identities/:identityAddress/email/validations', async (req, res, next) => {
  try {
    const { identityAddress } = req.params;
    const { code } = req.path;
    
    let email = emails.find(email => email.identityAddress === identityAddress);
    
    if (!email) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'Could not verify the email.', name: 'EMAIL_VERIFICATION_FAILED' });
    }
    
    if (email.status !== 'AWAITING_CONFIRMATION') {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'Could not verify the email.', name: 'EMAIL_VERIFICATION_FAILED' });
    }
    
    if (email.code !== code) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'Could not verify the email.', name: 'EMAIL_VERIFICATION_FAILED' });
    }
    
    email.status = 'VERIFIED';
    
    return res.sendStatus(204);
  } catch (err) {
    console.error(err);
        
    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
});

module.exports = router;
```

Update the `app.js` file to include the new router:

```javascript
// ./app.js
const express = require('express');
const app = express();

const AuthRoutes = require('./routes/auth.routes');
const EmailsRoutes = require('./routes/emails.routes');

app.use(express.json());

app.use('/auth', AuthRoutes);
app.use('/', EmailsRoutes);

app.listen(8080, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  
  console.info('Email Verification Service up an running 🎉');
});
```

Your service is now able to "verify" emails. You can integrate a mail service provider to really send the code to your users.

## Claim Issuance

Once we have validated the email, we will generate and a claim that the user can add to his Identity.

You will learn more about claims in the [official documentation of OnchainID](https://docs.onchainid.com/developers/providers/claim%20issuers/specification/). 

As there is not standard claim topic that contains only the email, we will create our own claim topic. let's say `97478264874`.

The private data of the claim will be the email itself (and a random identifier to avoid brute forcing of the claim hash to retrieve the email).

There will be no public data.

The "data" of the claim stored in the blockchain will be the hash of the private data (the `{ email, random }` object stringified and some other information like the emission data of the claim.

The Identity SDK has methods to create claims and generate their hash from their data.

Let's update our email verification route to create a claim when we receive a valid code. We will need a `SignerModule` that can sign the claims. The easiest way is to use a `Wallet`:

```javascript
// ./routes/emails.routes.js
const IdentitySDK = require('@onchain-id/identity-sdk');

const claims = [];

const wallet = new IdentitySDK.Providers.Wallet('some_private_key');
const signer = new IdentitySDK.SignerModule(wallet);

router.post('/identities/:identityAddress/email/validations', async (req, res, next) => {
  try {
    
    // ...
    
    email.status = 'VERIFIED';
    
    const claim = new IdentitySDK.Claim({
      address: identityAddress,
      emissionDate: new Date(),
      topic: 97478264874,
      privateData: {
        email: email.email,
        _random: uuidv4(),
      },
      publicData: {},
    });
    
    claim.hash = claim.generateHash();
    claim.data = claim.hash;
    
    await claim.sign(signer);
    
    claims.push(claim);
    
    console.log(claim);
    
    return res.sendStatus(204);
  } catch (err) {
    console.error(err);
        
    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
});
```
