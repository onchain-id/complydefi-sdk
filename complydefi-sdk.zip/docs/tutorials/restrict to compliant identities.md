# Restricting access to compliant Identities

We are going to create a service provider that needs to allows access to compliant Identities only.
We will implement a voting system, to which only users with a claim stating their name can access.
We will only accept a set of given Trusted Issuers for these claims.
Let's call it the Voting Service.

Our service will leverage the [OnchainID](https://onchainid.com) standard for Blockchain Identities.
Reach for the official website and documentation to learn more about the OnchainID standard.

## Bootstrap the API

For the sake of this tutorial, we will use a very simple `express` server.

First and foremost, create a new folder for your `./voting-service`.

Init your npm package `yarn init`. You may leave the fields as default.

Install the dependencies required for this tutorial. We will use `express` to run the API server `yarn add express`.

Some dev-dependencies will also be useful. `nodemon` watch our files and restart after each code change: `yarn add -D nodemon`.

Let's create our first file that define our API:

```javascript
// ./app.js
const express = require('express');
const app = express();

app.use(express.json());

app.listen(8080, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  
  console.info('Voting Service up an running 🎉');
});
```

We won't use any database here and store everything in memory,
but of course, you would connect to a persistence storage.

Let's update our `package.json` with an appropriate dev start script that automatically reloads on each code change:

```json
{
  "scripts": {
    "start": "node app.js",
    "start:dev": "nodemon app.js"
  }
}
```

## Create the vote endpoint

Our service won't use any authentication method.
Any person with a compliant Identity will be able to vote only once.
We are going to create a first endpoint on which Identity owners will be able to declare their vote.
Of course, an Identity can vote only once.

We will use random `uuid/v4` to generate unique identifiers, install with `yarn add uuid`.

To interact with Identities, we will use the Identity SDK: `yarn add @onchain-id/identity-sdk`.

```javascript
// ./routes/vote.routes.js
const express = require('express');
const IdentitySDK = require('@onchain-id/identity-sdk');
const uuidv4 = require('uuid/v4');

const router = express.Router();

const votes = {};

router.post('/', async (req, res, next) => {
  try {
    const { identityAddress, vote } = req.body;

    if (!vote) {
      res.status(400);
      return res.json({ error: true, status: 400, message: "Missing 'vote' in body.", name: 'INVALID_VOTE' });
    }

    let identity;
    try {
      identity = await IdentitySDK.Identity.at(identityAddress);
    } catch (err) {
      res.status(400);
      return res.json({ error: true, status: 400, message: 'The provided identityAddress is not a valid Ethereum address or the ENS could not be resolved.', name: 'INVALID_IDENTITY_ADDRESS' });
    }

    if (votes[identityAddress]) {
      res.status(409);
      return res.json({ error: true, status: 409, message: 'This identity has already submitted a vote.', voteID: votes[identityAddress].id, name: 'ALREADY_VOTED' });
    }

    const createdVote = {
      id: uuidv4(),
      identity: identityAddress,
      vote,
    };

    votes[identityAddress] = createdVote;

    res.status(201);
    return res.json({ id: createdVote.id });
  } catch (err) {
    console.error(err);

    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
});

module.exports = router;
```

Update the `app.js` file to include the new router. Also configure the default blockchain provider for the Identity SDK:

```javascript
// ./app.js
const express = require('express');
const IdentitySDK = require('@onchain-id/identity-sdk');

const VoteRoutes = require('./routes/vote.routes');

IdentitySDK.Config.setProvider('homestead');

const app = express();

app.use(express.json());

app.use('/auth', VoteRoutes);

app.listen(8080, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  
  console.info('Email Verification Service up an running 🎉');
});
```

## Verify Identity compliance

Now we want to make sure that only Identities with a COUNTRY claim from one of the Claim Issuers we trust can vote.

Let's update our voting route with this verification.

We will use the standard claim topic definition package, install with `yarn add @onchain-id/claim-topics`.
The Identity object has two important methods we will call: `.getClaimsByTopic`
which will retrieve all claims for a given topic on an Identity
and `.verifyClaim` that verify if the claim is still valid according to the Claim Issuer.

```javascript
const { ClaimTopicsByName } = require('@onchain-id/claim-topics');

router.post('/', async (req, res, next) => {
  try {
    // ...
    
    let claims;
    try {
      claims = await identity.getClaimsByTopic(ClaimTopicsByName.COUNTRY.id);
    } catch (err) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'Identity is not deployed or Blockchain cannot be reached.', name: 'INVALID_IDENTITY' });
    }

    const trustedClaims = claims.filter(claim => trustedClaimIssuers.includes(claim.issuer));

    if (trustedClaims.length === 0) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'No valid set of claims required to vote.', name: 'INVALID_IDENTITY' });
    }

    let verifiedClaim;
    for (let trustedClaim of trustedClaims) {
      const verificationStatus = await identity.verifyClaim(trustedClaim);

      if (verificationStatus.valid) {
        verifiedClaim = trustedClaim;
        break;
      }
    }

    if (!verifiedClaim) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'No valid set of claims required to vote.', name: 'INVALID_IDENTITY' });
    }

    // ...
  } catch (err) {
    // ...
  }
});
```

## Authenticate vote signature

Of course, we want only the Identity owner to be able to submit his vote.
To ensure this, we would generate a unique challenge that must be signed with a key authorized on the Identity.

This process is similar to the one used in the [Claim Issuer tutoriam](./access%20identity%20information.md)
to authenticate an Identity, so we won't detail it there.
You would add a message with a random ID in the create vote response,
and add a new route to submit vote verification with the signed message. 
