const express = require('express');
const { ClaimTopicsByName } = require('@onchain-id/claim-topics');
const IdentitySDK = require('@onchain-id/identity-sdk');
const uuidv4 = require('uuid/v4');

const router = express.Router();

const votes = {};

const trustedClaimIssuers = ['0xfd2C2D90c6F8572C4ece63D274A749125B844883', '0x343F5A37879E4BC82f7d8C045BfB61C2c23a2785'];

router.post('/', async (req, res, next) => {
  try {
    const { identityAddress, vote } = req.body;

    if (!vote) {
      res.status(400);
      return res.json({ error: true, status: 400, message: "Missing 'vote' in body.", name: 'INVALID_VOTE' });
    }

    let identity;
    try {
      identity = await IdentitySDK.Identity.at(identityAddress);
    } catch (err) {
      res.status(400);
      return res.json({ error: true, status: 400, message: 'The provided identityAddress is not a valid Ethereum address or the ENS could not be resolved.', name: 'INVALID_IDENTITY_ADDRESS' });
    }

    if (votes[identityAddress]) {
      res.status(409);
      return res.json({ error: true, status: 409, message: 'This identity has already submitted a vote.', voteID: votes[identityAddress].id, name: 'ALREADY_VOTED' });
    }

    let claims;
    try {
      claims = await identity.getClaimsByType(ClaimTopicsByName.COUNTRY.id);
    } catch (err) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'Identity is not deployed or Blockchain cannot be reached.', name: 'INVALID_IDENTITY' });
    }

    const trustedClaims = claims.filter(claim => trustedClaimIssuers.includes(claim.issuer));

    if (trustedClaims.length === 0) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'No valid set of claims required to vote.', name: 'INVALID_IDENTITY' });
    }

    let verifiedClaim;
    for (let trustedClaim of trustedClaims) {
      const verificationStatus = await identity.verifyClaim(trustedClaim);

      if (verificationStatus.valid) {
        verifiedClaim = trustedClaim;
        break;
      }
    }

    if (!verifiedClaim) {
      res.status(403);
      return res.json({ error: true, status: 403, message: 'No valid set of claims required to vote.', name: 'INVALID_IDENTITY' });
    }

    const createdVote = {
      id: uuidv4(),
      identity: identityAddress,
      vote,
    };

    votes[identityAddress] = createdVote;

    res.status(201);
    return res.json({ id: createdVote.id });
  } catch (err) {
    console.error(err);

    res.status(500);
    return res.json({ error: true, status: 500, message: 'An error occurred.', name: 'INTERNAL_SERVER_ERROR' });
  }
});

module.exports = router;
