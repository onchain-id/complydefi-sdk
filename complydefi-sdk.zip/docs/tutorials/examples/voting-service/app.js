const express = require('express');
const IdentitySDK = require('@onchain-id/identity-sdk');

const VoteRoutes = require('./routes/vote.routes');

const app = express();

IdentitySDK.Config.setProvider('http://localhost:8545');

app.use(express.json());

app.use('/votes', VoteRoutes);

app.listen(8080, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }

  console.info('Voting Service up an running 🎉');
});
