# Identity SDK usage examples

## Index

1. [Deploy an Identity](./1.%20deploy%20identity/1-deploy-identity.js)
2. [Manage an Identity](./2.%20manage%20identity/2-manage-identity.js)
3. [Identity Claims](./3.%20identity%20claims)
    - 3.1 [Explore claims of an Identity](./3.%20identity%20claims/3.1-list-identity-claims.js)
    - 3.2 [Access data of claims](./3.%20identity%20claims/3.2-access-claim-data.js)
    - 3.3 [Issue a claim](./3.%20identity%20claims/3.3-issue-claim.js)
    - 3.4 [Manage claims on an identity](./3.%20identity%20claims/3.4-manage-identity-claims.js) 
