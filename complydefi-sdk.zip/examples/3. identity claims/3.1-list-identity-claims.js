const IdentitySDK = require('@onchain-id/identity-sdk');

async function example() {
  // Configure IdentitySDK to use to ropsten test network.
  IdentitySDK.Config.setProvider('ropsten');

  // Fetch an identity by ethereum address, or Ethereum name.
  const identity = await IdentitySDK.Identity.at('someidentity.onchainid.xyz');

  // There is no direct way to list all claims of an Identity, they can only be retrieved by topic.
  // To fetch all claims, retrieve all ClaimAdded and ClaimRemoved events.
  const claims = await identity.getClaimsByTopic(1);
  console.log(claims[0]);
  /*
      {
        id: '0x...',
        topic: 1784,
        scheme: 1974,
        issuer: '0x...',
        signature: '0x...'',
        data: '0x...',
        uri: 'https://...',
      }
   */

  // Retrieve only claim IDs
  const claimIds = await identity.getClaimIdsByTopic(1);

  // Get a specific claim.
  const claim = await identity.getClaim(claimIds[0]);
}

(async () => {
  await example();
})();
