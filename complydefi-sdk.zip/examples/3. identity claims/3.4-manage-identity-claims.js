const IdentitySDK = require('@onchain-id/identity-sdk');

async function example() {
  // Configure IdentitySDK to use to ropsten test network.
  IdentitySDK.Config.setProvider('ropsten');

  // Get the configured provider to instantiate the wallets.
  const provider = IdentitySDK.Config.getProvider();

  const identityOwnerWallet = new IdentitySDK.Providers.Wallet('private_key', provider);

  const identity = await IdentitySDK.Identity.at('someidentity.onchainid.xyz');

  // As an Identity owner, or if you have a CLAIM key on an Identity, you may manage its claims.

  // If you have an issued claim, you may add it.
  // Self-Attested claims have the issuer being the identity contract address.
  const claim = {
    topic: 13,
    // ...
  };
  await identity.addClaim(claim.topic, claim.scheme, claim.issuer, claim.signature, claim.data, claim.uri, identityOwnerWallet);

  // You may also remove a claim.
  const claimID = IdentitySDK.utils.encodeAndHash(['address', 'uint256'], [claim.issuer, claim.topic]);

  const removeTX = await identity.removeClaim(claimID);
  await removeTX.wait();
}

(async () => {
  await example();
})();
