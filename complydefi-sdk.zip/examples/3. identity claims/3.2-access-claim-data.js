const IdentitySDK = require('@onchain-id/identity-sdk');

async function example() {
  // Configure IdentitySDK to use to ropsten test network.
  IdentitySDK.Config.setProvider('ropsten');

  // Fetch an identity by ethereum address, or Ethereum name.
  const identity = await IdentitySDK.Identity.at('someidentity.onchainid.xyz');

  // Suppose you want to access a claim of topic 10101000100001 (BASIC IDENTITY).
  const basicIdentityClaims = await identity.getClaimsByTopic(10101000100001);

  // Filter the claims to keep only those emitted by a list of claim issuers you trust.
  // To trust self-attested claims, add the Identity address in the list.
  const trustedClaimIssuers = [
    '0x1...',
    '0x2...',
  ];
  const trustedBasicIdentityClaims = basicIdentityClaims.filter(claim => trustedClaimIssuers.includes(claim.issuer));

  if (trustedBasicIdentityClaims.length === 0) {
    throw new Error('No claim issued by a Trusted Claim Issuer.');
  }

  // Select any of those claims, maybe you have a preference among the claim issuers you trust.
  const claim = new IdentitySDK.Claim(trustedBasicIdentityClaims[0]);

  // Populate the claim with off-chain information (public data).
  await claim.populate();

  console.log(claim.publicData);
  // { ... )

  // Create the Signer Module that will be used to access the data of the claim (consumer of the access grant).
  const yourServiceSigningModule = new IdentitySDK.SignerModule({
    publicKey: {
      key: "-----BEGIN CERTIFICATE----- my_super_public_key -----END CERTIFICATE-----",
      type: "X.509",
      signingMethod: "SHA-256",
    },
    signMessage: async (message) => {
      const signer = new jsrsasign.Signature({ alg: 'SHA256withRSA' });
      signer.init("-----BEGIN CERTIFICATE----- my_super_PRIVATE_no_really_super_secret_PRIVATE_key -----END CERTIFICATE-----");
      signer.updateString(message);
      return signer.sign();
    },
  });

  // Request access to the private claim data. Read documentation for more information about Access Grant types.
  const accessGrant = await claim.requestAccess(IdentitySDK.utils.enums.AccessGrantType.PERSISTENT, yourServiceSigningModule);

  // Request signature of accessRequest.challenge from Identity Owner, or wait for the user to approve the access grant via the Claim Issuer or Identity Service which stores the claim.
  // Wait
  // or
  // request signature then validate the access request
  accessGrant.signature = User.signMessage(accessRequest.challenge);

  const accessResult = await claim.completeAccessChallenge(accessGrant);
  console.log('accessResult', accessResult);
  // -> { ..., status: 'CONFIRMED' }

  // Use the persistent access grant to obtain an access token.
  const access = await claim.requestAccessToken(accessGrant, yourServiceSigningModule);
  console.log('accessToken', access);
  // -> { access: true, accessToken: '...' }

  // Populate the claim with the private data.
  await claim.populate(access.accessToken);
  console.log(claim.privateData);
}

(async () => {
  await example();
})();
