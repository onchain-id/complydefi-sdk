const IdentitySDK = require('@onchain-id/identity-sdk');

async function example() {
  // Configure IdentitySDK to use to ropsten test network.
  IdentitySDK.Config.setProvider('ropsten');

  // Get the configured provider to instantiate the wallets.
  const provider = IdentitySDK.Config.getProvider();

  // Create the Signing module that will sign the claim, from a wallet (convenient method).
  const claimIssuerSigningWallet = new IdentitySDK.Providers.Wallet('private_key', provider);
  const claimIssuerSigningModule = new IdentitySDK.SignerModule(claimIssuerSigningWallet);

  const claim = new IdentitySDK.Claim({
    address: '0xab4...', // address targeted by the claim.
    topic: 138, // claim topic (refer to standard claim topics if appropriate).
    scheme: 2, // claim scheme (refer to standard claim schemes).
    issuer: '0x1...', // the key holder contract that bears the private key used to sign the claim.
    uri: 'https://yourclaim.service.io', // the URL where to get the public and private data of the claim, if any.
  });

  claim.emissionDate = new Date(); // Date of emission.
  claim.publicData = {
    somePublicData: 'Hello',
    random: '173df-8793ab-...',
  };
  claim.privateData = {
    somePrivateData: 'World',
    random: 'eda78-ee67c-...',
  };
  claim.data = claim.generateHash(); // This is the easiest way to generate a claim data while allowing for proving offchain data validity.

  // Sign the claim.
  await claim.sign(claimIssuerSigningModule);
  console.log(claim.signature);
  // -> '0x....'

  // Send the claim to the Identity Owner, that will then add it to its Identity.
  const identityOwnerWallet = new IdentitySDK.Providers.Wallet('private_key', provider);

  const identity = await IdentitySDK.Identity.at('someidentity.onchainid.xyz');

  const addClaimTX = await identity.addClaim(claim.topic, claim.scheme, claim.issuer, claim.signature, claim.data, claim.uri, identityOwnerWallet);
  await addClaimTX.wait();
}

(async () => {
  await example();
})();
