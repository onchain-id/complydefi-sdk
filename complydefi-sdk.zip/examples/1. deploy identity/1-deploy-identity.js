const IdentitySDK = require('@onchain-id/identity-sdk');

async function example() {
  // Configure IdentitySDK to use to ropsten test network.
  IdentitySDK.Config.setProvider('ropsten');

  // Get the configured provider to instantiate the wallets.
  const provider = IdentitySDK.Config.getProvider();

  // Create the wallet that will own the Identity.
  const identityOwnerWallet = new IdentitySDK.Providers.Wallet('private_key', provider);

  // Deploy a new Identity contract.
  const identity = await IdentitySDK.Identity.deployNew(identityOwnerWallet).then(identity => identity.deployed());

  console.log(`The new Identity is deploying at address ${identity.address}...`);

  // Wait for contract deployment before calling other methods.
  await identity.claimHolderInstance.deployed();

  console.log('The identity was deployed.');
}

(async () => {
  await example();
})();
