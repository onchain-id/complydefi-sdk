const IdentitySDK = require('@onchain-id/identity-sdk');

async function example() {
  // Configure IdentitySDK to use to ropsten test network.
  IdentitySDK.Config.setProvider('ropsten');

  // Get the configured provider to instantiate the wallets.
  const provider = IdentitySDK.Config.getProvider();

  // Create the wallet that will own the Identity.
  const serviceWallet = new IdentitySDK.Providers.Wallet('private_key', provider);
  const identityOwnerWalletAddress = '0x1d........e9f';

  // Deploy a new Identity contract.
  const identity = await IdentitySDK.Identity.deployNew(serviceWallet).then(identity => identity.deployed());
  console.log('Await identity deployment confirmation.');
  await identity.claimHolderInstance.deployed();
  console.log(`The new Identity was deployed at address ${identity.address}...`);

  // Ads the address of the owner so that he gains rights over the Identity.
  const addKeyTransaction = await identity.addKey(IdentitySDK.utils.encodeAndHash(['address'], [identityOwnerWalletAddress]), IdentitySDK.utils.enums.KeyPurpose.MANAGEMENT, IdentitySDK.utils.enums.KeyType.ECDSA, serviceWallet);
  // Wait for transaction confirmation.
  await addKeyTransaction.wait();
  console.log('Added owner key to identity.');

  const keys = await identity.getKeysByPurpose(IdentitySDK.utils.enums.KeyPurpose.MANAGEMENT);
  console.log(keys);

  const key = await identity.getKey(keys[0].key);
  console.log(key);

  // Remove the service key so that the identity owner becomes the sole manager of the Identity.
  const removeKeyTransaction = await identity.removeKey(IdentitySDK.utils.encodeAndHash(['address'], [serviceWallet.address]), serviceWallet);
  // Wait for transaction confirmation.
  await removeKeyTransaction.wait();
  console.log('Removed service key from identity.');
}

(async () => {
  await example();
})();
