import {Key, KeyPurpose, KeyType} from "./Key.interface";
import { TransactionResponse } from '@ethersproject/providers';

export interface ERC734 {
  getKey(key: string): Promise<Key>;
  getKeyPurposes(key: string): Promise<KeyPurpose[]>;
  getKeysByPurpose(purpose: KeyPurpose): Promise<Key[]>;
  addKey(key: string, purpose: KeyPurpose, type: KeyType): Promise<TransactionResponse>;
  removeKey(key: string, purpose: KeyPurpose): Promise<TransactionResponse>;
}
