import { ERC734 } from './ERC734.interface';
import { ERC735 } from './ERC735.interface';

export interface IdentityInterface extends ERC734, ERC735 {}
