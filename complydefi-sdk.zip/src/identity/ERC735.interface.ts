import {ClaimData, ClaimScheme, ClaimTopic} from "../claim/Claim.interface";
import { TransactionResponse } from '@ethersproject/providers';

export interface ERC735 {
  getClaim(claimId: string): Promise<ClaimData>;
  getClaimIdsByTopic(topic: ClaimTopic | string): Promise<string[]>;
  getClaimsByTopic(topic: ClaimTopic | string): Promise<ClaimData[]>;
  addClaim(topic: ClaimTopic, scheme: ClaimScheme, issuer: string, signature: string, data: string, uri: string): Promise<TransactionResponse>;
  removeClaim(claimId: string): Promise<TransactionResponse>;
}
